Fisrtly, we are thankful you for chosing our software.......
So, Lets Start....

#-------------------------------------------------------------------------------
Regarding,installation :-

Step1 :- Firstly, Unzip the compressed file

#-------------------------------------------------------------------------------

Step2 :- Please Create databse named hotel

#-------------------------------------------------------------------------------

Step3 :- Please Create 2 tables in local server such as XAMPP
          1- registration
          2- checkin

NOTE :- Please ensure that, fields are exactly same as here :

1.For registration (All in varchar)
  name
  Phoneno
  Gmail
  Address
  country
  id
  idnumber

2. For checkin (All in varchar)
   Phoneno   - Unique key
   date
   ndays
   roomtype
   roomno     - Primary key
   adults
   children
          
#--------------------------------------------------------------------------------

Step4 :- Now, Start the .exe file and enjoy our software...

         username = admin
         password = admin



